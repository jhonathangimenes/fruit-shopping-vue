<template>
    <li class="list-group-item">
        <img :src="require('../assets/'+this.fruit.img)" width="50px" height="50px"/>
        <span>{{ descriptionFormatted }}</span>
        <span>{{ valueFormatted }}</span>
    </li>
</template>

<script>
export default {
    props: {
        fruit: {
            type: Object,
            required: true
        }
    },
    computed: {
        valueFormatted() {
            return this.fruit.value.toLocaleString("pt-BR",
                { style: 'currency', currency: 'BRL' }
            )
        },
        descriptionFormatted() {
            return this.fruit.description.substr(0,1).toUpperCase()+this.fruit.description.substr(1)
        }
    }
}
</script>